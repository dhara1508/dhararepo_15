package program1;
	public class coverter
{
	public static void main(String args[]) {
		String txt = "Dhara";
		
		{
			System.out.println(txt.toLowerCase());
			System.out.println(txt.toUpperCase());
		}
	}
}