package program1;

public class datatype {
	public static void main(String args[]) {
		int a = 123;
		float b = 10.20f;
		char c = 'a';
		String d = "Dhara";
		Boolean isright = true;
		 
		{
			System.out.println(a);	
			System.out.println(b);
			System.out.println(c);
			System.out.println(d);
			System.out.println(isright);
			
		}
    }
	}