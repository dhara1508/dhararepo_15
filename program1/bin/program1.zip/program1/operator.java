package program1;

public class operator {
	public static void main(String args[]) {
		int a , b, c, d, e,f;
//		int b;
//		int c;
//		int d;
//		int e;
//		int f;
		a = 10;
		b = 5;
		
		c = a+b;
		d = a-b;
		e = a*b;
		f = a/b;
		{
		System.out.println("This is the value of the Sum " + c);
		System.out.println("This is the value of the Substraction " + d);
		System.out.println("This is the value of the Multiplication " + e);
		System.out.println("This is the value of the Division " + f);
		}
		
	}

}
