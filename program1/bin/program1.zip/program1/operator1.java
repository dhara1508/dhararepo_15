package program1;

public class operator1 {
	public static void main(String args[]) {
	int x = 15;
	int y = 10;
//	x == y;
	{
		System.out.println(x<15 && y>10);
	}

}
} 

