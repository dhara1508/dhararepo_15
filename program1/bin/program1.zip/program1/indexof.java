package program1;
public class indexof{
	
public static void main(String args[]) {
	String txt = "Please locate where 'Locate' occurs!"; 
	{
		System.out.println(txt.indexOf("where"));
	}
}

}