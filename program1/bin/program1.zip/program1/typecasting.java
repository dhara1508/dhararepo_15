package program1;
public class typecasting{
	public static void main(String args[]) {
		double mydouble = 10.10;
		int myint = (int)mydouble;  // manually convert 
		{
		System.out.println(myint);
		System.out.println(mydouble);
		}
	}
}