package program1;
public class math {
	
	public static void main (String args[]) {
		int x = 200;
		int y = 150;
		int z = -50;
	    int randomNum = (int)(Math.random() * 101);  // 0 to 100
		{
			System.out.println(Math.max(x,y));
			System.out.println(Math.min(x,y));
			System.out.println(Math.sqrt(x));
			System.out.println(Math.abs(z));
			System.out.println(Math.random());
			System.out.println(randomNum);
		}
	}
}


